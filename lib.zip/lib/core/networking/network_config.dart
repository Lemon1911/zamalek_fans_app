class NetworkConfig {
  static const String baseUrl = 'https://v3.football.api-sports.io/';
  static const Map<String, String> headers = {
    'x-rapidapi-key': '8f65f483b1254a2ec20a77591abfa9f6',
  };
}
