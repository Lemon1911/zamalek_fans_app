class User {
  final String uid;
  final String email;

  User({required this.uid, required this.email});
}
